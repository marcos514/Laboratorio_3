<?php
include "IMiddleWare.php";
include "AccesoDatos.php";
class Verificadora implements IMiddleWare
{
    private static $objetoPDO;

    public static function VerificarUsuario($request, $response, $next)
    {

        if(!$request->isGet())
        {
            
            $objetoAccesoDato =new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', 'root', '');
            $json=$request->getParsedBody();
            $nombre=$json["nombre"];
            $clave=$json["clave"];
            $consulta =$objetoAccesoDato->prepare('select * from usuarios where nombre = :nombre and clave=:clave');
            
            $consulta->execute(array("nombre"=>$nombre,"clave"=>$clave));
            if($consulta->fetch()>0)
            {
                $response=$next($request, $response);
            }
		    return $response;
        }
        else
        {
		    $response=$next($request, $response);
		    return $response;           
        }
        		
    }
    public static function VerificarAdmin($nombre, $clave)
    {
        $objetoAccesoDato =new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', 'root', '');
        $consulta =$objetoAccesoDato->prepare('select * from usuarios where nombre = :nombre and clave=:clave');
            
        $consulta->execute(array("nombre"=>$nombre,"clave"=>$clave));
        $usuario=$consulta->fetch();
        if($usuario>0)
        {
            if($usuario[0]["perfil"]=="super_admin")
            {
                return true;
            }
            return false;
        }
        return false;
    }
    
}






?>