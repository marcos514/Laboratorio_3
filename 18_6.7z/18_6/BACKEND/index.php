<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";
include "clases/Verificadora.php";
include_once "clases/cd.php";
use Firebase\JWT\JWT as JWT;


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);

$app->group('/test', function () {

    $this->post('[/]', function ($request, $response) {   
        
        
        $parse=$request->getParsedBody();
        $clave=$parse["clave"];
        $usuario=$parse["usuario"];
        $array=array("clave"=>$clave,"usuario"=>$usuario,"exp"=>time()+1000,"iat"=>time());
        $token=JWT::encode($array,"clave");
        
        return $response->withJson($token,200);
    });

    $this->get('[/]', function ($request, $response,$arg) {   
        try
        {
            $todo= JWT::decode($_GET["token"],"clave",["HS256"]);
            $response->getBody()->write("El usuario es: ".$todo->usuario);
            return $response;
        }
        catch(Exception $e)
        {
            throw $e;

        }
        
        
        
    });
    $this->put('[/]', function ($request, $response,$arg) {   
        /*$parse=$request->getParsedBody();
        $token=$parse["token"];
        try
        {
            $todo= JWT::decode($token,"clave",["HS256"]);
            $response->getBody()->write("El usuario es: ".$todo->usuario);
            return $response;
        }
        catch(Exception $e)
        {
            throw $e;

        }*/
        
        
        
    });
     
})/*->add(\Usuario::class. "::AgregarUsuario")*/;

$app->post('[/]', function ($request, $response) {   
    $cd=new cd();
    $json=$request->getParsedBody();
    $cd->titulo=$json["titulo"];
    $cd->cantante=$json["cantante"];
    $cd->año=$json["año"];
    try
        {
            $todo= JWT::decode($json["token"],"clave",["HS256"]);
            $response->getBody()->write("token valido");
        }
        catch(Exception $e)
        {
            throw $e;

        }

    
    $response->getBody()->write($cd->InsertarElCd());

    
    return $response;
    
});
$app->get('[/]', function (Request $request, Response $response) { 
    $header=($request->getHeader("token"));
    try
    {
        $todo= JWT::decode($header[0],"clave",["HS256"]);
    }
    catch(Exception $e)
    {
        throw $e;
    }   
    $cd=new cd();
    $todo=cd::TraerTodoLosCds();
    
    
    //$response=$response->withJson($todo, 200);
   return $response->withJson($todo, 200);
});

//$app->add(\Verificadora::class."::VerificarUsuario");
$app->run();

?>