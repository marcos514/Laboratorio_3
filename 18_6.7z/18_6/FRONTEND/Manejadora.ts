/// <reference path="../node_modules/@types/jquery/index.d.ts" />
class Manejadora 
{
    public static LogIn()
    {
        let pagina : string = "../BACKEND/index.php/test";
            
            let nombre:string= (<HTMLInputElement>document.getElementById("txtUsuario")).value;
            let clave:string=(<HTMLInputElement>document.getElementById("txtClave")).value;
            let formData : FormData = new FormData();
            formData.append("clave", nombre);
            formData.append("usuario",clave );

            // es attr si es 1.9 o menor
            //$("#txtPatente").prop('readOnly', false);

            $.ajax({
                type: 'POST',
                url: pagina,
                dataType:"json",
                data: formData,
                contentType: false,
                processData: false,
            })
            .done(function (objJson) {

                localStorage.setItem("mitoken",objJson);
                location.href ="listado.php";
                console.log(objJson);
            })
            .fail(function(aaa){
                console.log(JSON.stringify(aaa));
                
            });
    }
    public static Listar()
    {
        var pagina = "../BACKEND/index.php";


        // es attr si es 1.9 o menor
        //$("#txtPatente").prop('readOnly', false);
        var token=localStorage.getItem("mitoken");

        $.ajax({
            type: 'GET',
            url: pagina,
            dataType:"json",
            contentType: false,
            processData: false,
            headers:{"token":token}
        })
        .done(function (objJson) {
            let i:number=0;
            let lista:string='<div class="row"><div class="col-sm-3  col-md-3 col-xs-3 ">Titulo</div><div class="col-sm-3  col-md-3 col-xs-3 ">Cantante</div><div class="col-sm-3  col-md-3 col-xs-3 ">Año</div></div>';
            for (let i = 0; i < objJson.length; i++) {
                
            lista+='<div class="row"><div class="col-sm-3  col-md-3 col-xs-3 ">'+objJson[i].titulo+'</div><div class="col-sm-3  col-md-3 col-xs-3 ">'+objJson[i].cantante+'</div><div class="col-sm-3  col-md-3 col-xs-3 ">'+objJson[i].año+'</div></div>';
            }
            $("#divLista").html(lista);
            
        })
        .fail(function(aaa){
            console.log(JSON.stringify(aaa));
        });
    }
}