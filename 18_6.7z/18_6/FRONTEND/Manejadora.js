"use strict";
/// <reference path="../node_modules/@types/jquery/index.d.ts" />
var Manejadora = /** @class */ (function () {
    function Manejadora() {
    }
    Manejadora.LogIn = function () {
        var pagina = "../BACKEND/index.php/test";
        var nombre = document.getElementById("txtUsuario").value;
        var clave = document.getElementById("txtClave").value;
        var formData = new FormData();
        formData.append("clave", nombre);
        formData.append("usuario", clave);
        // es attr si es 1.9 o menor
        //$("#txtPatente").prop('readOnly', false);
        $.ajax({
            type: 'POST',
            url: pagina,
            dataType: "json",
            data: formData,
            contentType: false,
            processData: false,
        })
            .done(function (objJson) {
            localStorage.setItem("mitoken", objJson);
            location.href = "listado.php";
            console.log(objJson);
        })
            .fail(function (aaa) {
            console.log(JSON.stringify(aaa));
        });
    };
    Manejadora.Listar = function () {
        var pagina = "../BACKEND/index.php";
        // es attr si es 1.9 o menor
        //$("#txtPatente").prop('readOnly', false);
        var token = localStorage.getItem("mitoken");
        $.ajax({
            type: 'GET',
            url: pagina,
            dataType: "json",
            contentType: false,
            processData: false,
            headers: { "token": token }
        })
            .done(function (objJson) {
            var i = 0;
            var lista = '<div class="row"><div class="col-sm-4  col-md-4 col-xs-4 ">Titulo</div><div class="col-sm-4  col-md-4 col-xs-4 ">Cantante</div><div class="col-sm-4  col-md-4 col-xs-4 ">Año</div></div>';
            for (var i_1 = 0; i_1 < objJson.length; i_1++) {
                lista += '<div class="row"><div class="col-sm-4  col-md-4 col-xs-4 ">' + objJson[i_1].titulo + '</div><div class="col-sm-4  col-md-4 col-xs-4 ">' + objJson[i_1].cantante + '</div><div class="col-sm-4  col-md-4 col-xs-4 ">' + objJson[i_1].año + '</div></div>';
            }
            $("#divLista").html(lista);
        })
            .fail(function (aaa) {
            console.log(JSON.stringify(aaa));
        });
    };
    return Manejadora;
}());
