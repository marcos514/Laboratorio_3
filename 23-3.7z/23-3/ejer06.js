"use strict";
function Cuadrado(numero) {
    return numero * numero;
}
function Mostrar() {
    console.log(Cuadrado(10));
}
Mostrar();
//# sourceMappingURL=ejer06.js.map