"use strict";
console.log("HOLA MUNDOOOOOO!!!!!!!!!!!!!!\nPuedo mostrar comillas `simples`\nY comillas \"dobles\"");
//# sourceMappingURL=ejer01.js.map