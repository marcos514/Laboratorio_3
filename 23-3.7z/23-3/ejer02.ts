var meses : string[]=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Nobiembre","Diciembre"];
for(var i=0;i<12;i++)
{
    console.log(`${i} - ${meses[i]}\n`);
}