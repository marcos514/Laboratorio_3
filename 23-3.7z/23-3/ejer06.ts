function Cuadrado(numero:number):number
{
    return numero * numero;
}

function Mostrar():void
{
    console.log(Cuadrado(10));
}

Mostrar();