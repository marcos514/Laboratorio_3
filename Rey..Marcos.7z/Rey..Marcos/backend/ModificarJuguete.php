<?php
include_once "clases/Juguete.php";


$extencion=pathinfo($_FILES["img"]["name"],PATHINFO_EXTENSION);
$tmp_name=$_FILES["img"]["tmp_name"];
if(($extencion!="png"&&$extencion!="jpg"&&$extencion!="jpeg") )
{
    echo "Error, no es una foto<br><a href='../frontEnd/index.php'><h2>Volver a agregar un empleado</h2></a>";
    $validador=false;
}
else
{
    $tipo=$_POST["tipo"];
    $precio=$_POST["precio"];
    $pais=$_POST["pais"];
    $foto=$tipo.$pais.date("H_i")."jpg";
    

    $juguete=new Juguete($tipo,$precio,$paisOrigen,$foto);
    if($juguete->Modificar())
    {
        
        rename($tmp_name,"juguetes/imagenes/".$foto);
        header("Location: Listado.php");
    }
    else
    {
        echo "Juguete existente";
    }

    
}


   
    
?>


