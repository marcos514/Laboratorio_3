<?php
    include "clases/Juguete.php";
    $retourno="<table>
    <thead>
        <tr>
            <td>
                Tipo
            </td>
            <td>
                Pais
            </td>
            <td>
                Precio
            </td>
            <td>
                Foto
            </td>
        </tr>
    </thead>
    ";
    $datos=Juguete::Traer();
    foreach ($datos as $key) 
    {
        $array=explode(" - ",$key);
        $retourno.="
        <tr>
                <td>
                    ".$array[0]."
                </td>
                <td>
                ".$array[2]."
                </td>
                <td>
                ".$array[1]."
                </td>
                <td>
                    <img src='juguetes/imagenes/".$array[3]." width='50px' height='50px' >
                </td>
            </tr>";
    }

    $retourno.="</table>";
    echo $retourno;



?>