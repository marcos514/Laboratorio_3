<?php
 //tipo, el precio y el paisOrigen
    include "clases/Juguete.php";
    $tipo=isset($_POST["tipo"])? $_POST["tipo"]:false;
    $precio=isset($_POST["precio"])? $_POST["precio"]:false;
    $pais=isset($_POST["pais"])? $_POST["pais"]:false;

    if($tipo!=false&&$precio!=false && $tipo!=false)
    {
        $juguete=new Juguete($tipo,$precio,$pais);
        if($juguete->Agregar())
        {
            $archivo=fopen("archivos/juguetes_sin_fotos.txt","a");
            
            $hora=date("H_i");
            fwrite($archivo, $hora." - ".$juguete->ToString()."\r\n");
            echo "Agregado con exito";
            fclose($archivo);
        }
        else
        {
            echo $juguete->ToString();
        }
    }

?>