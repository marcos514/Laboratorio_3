<?php
    include "clases/Juguete.php";
    echo Juguete::MostrarLog();


?>