<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";
require_once "./clases/Usuarios.php";
require_once "./clases/MW.php";
require_once "./clases/Anteojo.php";
$MW=new MW();



use Firebase\JWT\JWT as JWT;


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);




$app->post('/usuarios', function ($request, $response) 
{
    if(isset($_FILES["foto"]))
    {
        $extencion=pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);
        $tmp_name=$_FILES["foto"]["tmp_name"];

        if(($extencion!="png"&&$extencion!="jpg"&&$extencion!="jpeg") )
        {
            return $response->withJson("formato",200);
        }
        else
        {
            $mail=$_POST["mail"];
            $clave=$_POST["clave"];
            $nombre=$_POST["nombre"];
            $apellido=$_POST["apellido"];
            $perfil=$_POST["perfil"];
            $foto="fotos/".$mail.".jpg";



            try
            {
                if (filter_var($mail, FILTER_VALIDATE_EMAIL)) 
                {
                    $usuario=new Usuario("",$nombre,$apellido,$mail,$foto,$clave,$perfil);
                    if(file_exists($foto)!=true)
                    {
                        if($usuario->Agregar()>0)
                        {
                            move_uploaded_file($tmp_name,$foto);   
                            return $response->withJson("Agregado",200);
                        }
                        else
                        {
                            return $response->withJson("Error al agregarlo a la base de datos",200);
                        }
                    }
                    return $response->withJson("Mail Repetido",200);                    
                    
                }
                else
                {
                    return $response->withJson("Mail Erroneo",200);
                }
                   
            }
            catch(Exception $e)
            {
                throw $e;

            }

        }
    }
    
    
});


$app->post('[/]', function ($request, $response) 
{
   
    $color=$_POST["color"];
    $marca=$_POST["marca"];
    $precio=$_POST["precio"];
    $aumento=$_POST["aumento"];
        
    $anteojo=new Anteojo("",$color,$marca,$precio,$aumento);

    if($anteojo->Agregar()>0)
    {
        return $response->withJson("Agregado",200);
    }
    else
    {
        return $response->withJson("Error al agregarlo a la base de datos",200);
    }
    return $response->withJson("FatalError",200);                    

    
});

$app->get('/anteojos', function ($request, $response) 
{

   $medias=Anteojo::TraerTodo();
    $str="{";
    $i=0;
    foreach ($medias as $key) 
    {
        if($str=="{")
        {
            $str.='"'.$i.'":{"id":'.$key["id"].',"color":"'.$key["color"].'","marca":"'.$key["marca"].'","precio":'.$key["precio"].',"talle":"'.$key["aumento"].'"}';
        }
        else
        {
            $str.=',"'.$i.'":{"id":'.$key["id"].',"color":"'.$key["color"].'","marca":"'.$key["marca"].'","precio":'.$key["precio"].',"talle":"'.$key["aumento"].'"}';
        }
        $i++;
        
    }
    $str.="}";
    if($str=="{}")
    {
        $str='{"Error":"Error"}';
    }
    return $response->withJson(json_decode($str),200);                    

    
});

$app->get('[/]', function ($request, $response) 
{

   $usuarios=Usuario::TraerTodo();
    $str="{";
    $i=0;
    foreach ($usuarios as $key) 
    {
        if($str=="{")
        {
            $str.='"'.$i.'":{"id":'.$key["id"].',"nombre":"'.$key["nombre"].'","apellido":"'.$key["apellido"].'","foto":"'.$key["foto"].'","mail":"'.$key["correo"].'","perfil":"'.$key["perfil"].'"}';
        }
        else
        {
            $str.=',"'.$i.'":{"id":'.$key["id"].',"nombre":"'.$key["nombre"].'","apellido":"'.$key["apellido"].'","foto":"'.$key["foto"].'","mail":"'.$key["correo"].'","perfil":"'.$key["perfil"].'"}';
        }
        $i++;
        
    }
    $str.="}";
    if($str=="{}")
    {
        $str='{"Error":"Error"}';
    }
    return $response->withJson(json_decode($str),200);                    

    
});

$app->delete('[/]', function ($request, $response) 
{
    $token=($request->getHeader("token")[0]);
    $id=($request->getHeader("id")[0]);

    $media=new Media("","","","",$id);
    if($media->BorrarEste()>0)
    {
        return $response->withJson("Media borrada",200);   
    }
    return $response->withJson("Error media no encontrada",200);               
                

    
})->add(\MW::class."::ComprobarPropietario")->add(\MW::class.":ComprobarToken");

$app->put('[/]', function ($request, $response) 
{

    $id=($request->getHeader("id")[0]);
    $marca=($request->getHeader("marca")[0]);
    $precio=($request->getHeader("precio")[0]);
    $talle=($request->getHeader("talle")[0]);
    $color=($request->getHeader("color")[0]);

    $media=new Media($color,$marca,$precio,$talle,$id);
    if(0<$media->ModificarEste())
    {
        return $response->withJson("Media Modificada",200);   
    }
    return $response->withJson("Error media no encontrada",200);                        

    
})->add(\MW::class.":ComprobarEncargado")->add(\MW::class.":ComprobarToken");




$app->group('/login', function () {

    $this->post('[/]', function ($request, $response) 
    {   
        $mail=$_POST["mail"];
        $clave=$_POST["clave"];
        $usuario=new Usuario("","","",$mail,"",$clave,"");
        $usuariosObtenidos=$usuario->TraerEste();
        //var_dump($usuariosObtenidos);
        if($usuariosObtenidos>0)
        {
            $array=array("mail"=>$usuariosObtenidos["mail"],"nombre"=> $usuariosObtenidos["nombre"],"perfil"=>$usuariosObtenidos["perfil"]);
            $token=JWT::encode($array,"clave");
            return $response->withJson($token,200);
        }    
        return $response->withJson("Error",200);
        

    })->add(\MW::class.":ComprobarBD")->add(\MW::class."::ComprobarValor")->add(\MW::class.":ComprobarSeteo");


    $this->get('[/]', function ($request, $response) 
    {        
        $token=($request->getHeader("token")[0]);
        try
        {
            $todo= JWT::decode($token,"clave",["HS256"]);
            return $response->withJson('{"mensaje":"Token esxitoso"}',200);   
        }
        catch(Exception $e)
        {
            return $response->withJson('"mensaje":"Token invalido"',409);   
        }
    });


     
});










$app->run();

?>