<?php
    include "clases/Juguete.php";
    $tipo=$_GET["tipo"];
     $pais=$_GET["pais"];
    $array=Juguete::Traer();
    foreach ($array as $key) {
        $partes=explode(" - ",$key);
        if($partes[0]==$tipo && $pais==$partes[2])
        {
            $j=new Juguete($tipo,$partes[1],$pais,$partes[3]);
            echo $j->ToString()."\n".$j->CalcularIVA();
        }
    }


?>