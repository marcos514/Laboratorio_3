<?php
include_once "AccesoDatos.php";
include_once "IParte1.php";

class Juguete implements IParte1
{
    public $tipo;
    public $paisOrigen;
    public $pathImagen;
    public $precio;
    public function __construct($tipo,$precio,$paisOrigen,$pathImagen="")
    {
        $this->tipo=$tipo;
        $this->precio=$precio;
        $this->pathImagen=$pathImagen;
        $this->paisOrigen=$paisOrigen;

    }

    public function ToString()
    {
        return $this->tipo." - ".$this->precio." - ". $this->paisOrigen ." - ".$this->pathImagen;
    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into juguetes (tipo, pais, precio , foto)values(:color, :marca, :precio , :aumento)");
    
        $consulta->bindValue(':precio',$this->precio,  PDO::PARAM_STR);
        $consulta->bindValue(':aumento', $this->pathImagen, PDO::PARAM_STR);
        $consulta->bindValue(':marca', $this->paisOrigen, PDO::PARAM_STR);
        $consulta->bindValue(':color', $this->tipo, PDO::PARAM_STR);
        if($consulta->execute()>0)
            return true;
        else
            return false;
    }


    public static function MostrarLog()
    {
        $archivo=fopen("../archivos/juguetes_sin_fotos.txt","r");
        $ret="";
        while( ! feof($archivo))
        {
            $ret.=fgets($archivo);
        }
        fclose($archivo);
        return $ret;
    }
    public static function Traer()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("select * from juguetes");
        $consulta->execute();
        $array=[];
        foreach ($consulta->fetchAll(PDO::FETCH_ASSOC) as $key)
        {
            $juguete=new Juguete($key["tipo"],$key["precio"],$key["pais"],$key["foto"]);
            array_push($array,$juguete->ToString());
        }	
        return $array;
    }
    public function CalcularIVA()
    {
        return $this->precio*1.21;
    }
    public function Verificar($array)
    {
        foreach ($array as $key) 
        {
            if($key==$this->ToString());
             return true;
        }
        return false;
    }
    public function Modificar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();         
		$consulta =$objetoAccesoDato->RetornarConsulta("UPDATE `jueguetes` SET `tipo`='".$this->tipo."',`precio`='".$this->precio."',`pais`='".$this->paisOrigen."',`foto`='".$this->pathImagen."' WHERE id=".$this->id);
						
		return $consulta->execute();	
    }



    /*public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into anteojos (color, marca, precio , aumento)values(:color, :marca, :precio , :aumento)");
        $consulta->bindValue(':precio',$this->precio,  PDO::PARAM_STR);
        $consulta->bindValue(':aumento', $this->aumento, PDO::PARAM_STR);
        $consulta->bindValue(':marca', $this->marca, PDO::PARAM_STR);
        $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }
    
    public static function TraerTodo()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from anteojos");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }

    public function BorrarEste()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("DELETE from medias WHERE id=".$this->id);
            $consulta->execute();
            return $consulta->rowCount();	
    }
    
    public function ModificarEste()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("UPDATE `medias` SET `color`='".$this->color."',`marca`='".$this->marca."',`precio`='".$this->precio."',`talle`='".$this->talle."' WHERE id=".$this->id);
						
			return $consulta->execute();		
    }

    public function TraerEste()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select  from Productos where nombre='".$this->nombre."'");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}*/



}







?>