<?php
interface IParte1
{
    function Agregar();
    static function Traer();
    function CalcularIVA();
    function Verificar($array);
    function Modificar();
}



?>