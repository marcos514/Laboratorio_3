"use strict";
var Entidades;
(function (Entidades) {
    var Ropa = /** @class */ (function () {
        function Ropa(codigo, nombre, precio) {
            this._codigo = codigo;
            this._nombre = nombre;
            this._precio = precio;
        }
        Ropa.prototype.ToString = function () {
            var strJson = "\"codigo\":\"" + this._codigo + "\",\"precio\":" + this._precio + ",\"nombre\":\"" + this._nombre + "\"";
            //let objJason:JSON=JSON.parse(strJson);
            return strJson;
        };
        return Ropa;
    }());
    Entidades.Ropa = Ropa;
})(Entidades || (Entidades = {}));
//# sourceMappingURL=Ropa.js.map