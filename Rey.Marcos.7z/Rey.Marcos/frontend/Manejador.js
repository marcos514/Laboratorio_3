"use strict";
/// <reference path="node_modules/@types/jquery/index.d.ts" />
var Manejador = /** @class */ (function () {
    function Manejador() {
    }
    Manejador.ArrayJson = function () {
        var strJson = '[{"mail":"tomas@gmail.com","clave":"1234","nombre":"tomas","apellido":"martin","legajo":"5621","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"marcos@gmail.com","clave":"1234","nombre":"marcos","apellido":"rey","legajo":"789","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"tomas@gmail.com","clave":"1234","nombre":"tomas","apellido":"sanchez","legajo":"5648","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"juan@gmail.com","clave":"1234","nombre":"juan","apellido":"siñeris","legajo":"1264","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"mica@gmail.com","clave":"1234","nombre":"micaela","apellido":"saez","legajo":"555","perfil":"invitado","foto":"fotos/1234.jpg"}]';
        if (localStorage.getItem("arrayJson")) {
            console.log("Usuarios cargados con antelacion");
            console.log(localStorage.getItem("arrayJson"));
        }
        else {
            localStorage.setItem("arrayJson", strJson);
            console.log(strJson);
        }
    };
    Manejador.ValidarCamposUsuario = function () {
        $("#divAlert").html("");
        var nombre = $("#nombre").val();
        var mail = $("#mail").val();
        var clave = $("#clave").val();
        var clave2 = $("#claveComparar").val();
        var foto = document.getElementById("foto");
        var apellido = $("#apellido").val();
        var legajo = $("#legajo").val();
        var validadorNombre = false;
        var validadorClave = false;
        var validadorClave2 = false;
        var validadorMail = false;
        var validadorApellido = false;
        var validadorLegajo = false;
        var validadorFoto = false;
        var mensaje = "";
        if (nombre == "") {
            document.getElementById("spnNombre").style.display = "block";
            mensaje += "Ingresar nombre<br>";
            validadorNombre = true;
        }
        else if (nombre.length > 10) {
            document.getElementById("spnNombre").style.display = "block";
            mensaje += "Nombre muy largo<br>";
            validadorNombre = true;
        }
        if (apellido == "") {
            document.getElementById("spnApellido").style.display = "block";
            mensaje += "Ingresar Apellido<br>";
            validadorApellido = true;
        }
        else if (apellido.length > 15) {
            document.getElementById("spnApellido").style.display = "block";
            mensaje += "Apellido muy largo<br>";
            validadorApellido = true;
        }
        if (legajo == "") {
            document.getElementById("spnLegajo").style.display = "block";
            mensaje += "Ingresar Legajo<br>";
            validadorApellido = true;
        }
        else if (legajo.length > 6 || legajo.length < 3) {
            document.getElementById("spnLegajo").style.display = "block";
            mensaje += "Legajo formato erroneo<br>";
            validadorApellido = true;
        }
        if (mail == "") {
            document.getElementById("spnMail").style.display = "block";
            mensaje += "Ingresar Mail<br>";
            validadorMail = true;
        }
        else {
            var emailRegex = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            //Se muestra un texto a modo de ejemplo, luego va a ser un icono
            if (emailRegex.test(mail)) {
            }
            else {
                document.getElementById("spnMail").style.display = "block";
                validadorMail = true;
                mensaje += "Formato del mail erroneo<br>";
            }
        }
        if (clave == "") {
            document.getElementById("spnClave").style.display = "block";
            mensaje += "Ingresar Clave<br>";
            validadorNombre = true;
        }
        else if (clave.length > 8 || clave.length < 4) {
            document.getElementById("spnClave").style.display = "block";
            mensaje += "Clave muy largo<br>";
            validadorClave = true;
        }
        if (clave2 == "") {
            document.getElementById("spnClaveRepetir").style.display = "block";
            mensaje += "Ingrese confirmacion de clave<br>";
            validadorNombre = true;
        }
        else if (clave2.length > 8 || clave2.length < 4) {
            document.getElementById("spnClaveRepetir").style.display = "block";
            mensaje += "Clave a confirmar formato erroneo<br>";
            validadorClave = true;
        }
        if (foto.files.length == 0) {
            document.getElementById("spnFoto").style.display = "block";
            mensaje += "Ingresar Foto <br>";
            validadorFoto = true;
        }
        else {
            var foto_1 = document.getElementById("foto");
            var form = new FormData();
            if (foto_1.files.length == 0) {
                alert("Error");
                return "";
            }
            form.append("foto", foto_1.files[0]);
            $.ajax({
                type: 'POST',
                url: "../BACKEND/",
                dataType: "json",
                data: form,
                contentType: false,
                processData: false,
            })
                .done(function (objJson) {
                if (objJson == "error") {
                    document.getElementById("spnFoto").style.display = "block";
                    mensaje += "Extencion foto invalido <br>";
                    validadorFoto = true;
                }
            })
                .fail(function (aaa) {
                console.log(JSON.stringify(aaa));
            });
        }
        if (mensaje != "") {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>' + mensaje + '</strong></div>');
            return true;
        }
        else {
            return false;
        }
    };
    Manejador.AgregarUsuario = function () {
        $("#divAlert").html("");
        if (Manejador.ValidarCamposUsuario()) {
            return "";
        }
        var nombre = $("#nombre").val();
        var mail = $("#mail").val();
        var clave = $("#clave").val();
        var clave2 = $("#claveComparar").val();
        var foto = document.getElementById("foto");
        var apellido = $("#apellido").val();
        var perfil = $("#perfil").val();
        var legajo = $("#legajo").val();
        if (clave == clave2) {
            var arrayJson = localStorage.getItem("arrayJson");
            var json = JSON.parse(arrayJson);
            var validador = false;
            for (var i = 0; i < json.length; i++) {
                if (mail == json[i].mail) {
                    validador = true;
                    break;
                }
            }
            if (validador) {
                $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error Mail ya ingresado</strong></div>');
            }
            else {
                var usuarioNuevo = JSON.parse('{"mail":"' + mail + '","clave":"' + clave + '","nombre":"' + nombre + '","apellido":"' + apellido + '","legajo":"' + legajo + '","perfil":"' + perfil + '","foto":"' + json.length + '.jpg"}');
                json.push(usuarioNuevo);
                localStorage.setItem("arrayJson", JSON.stringify(json));
                location.href = "login.html";
            }
        }
        else {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error la contraceña no coincide con el mail</strong></div>');
        }
    };
    Manejador.validador = function () {
        $("#divAlert").html("");
        var mail = $("#mail").val();
        var clave = $("#clave").val();
        var mensaje = "";
        var mailErroneo = false;
        var claveErroneo = false;
        if (mail == "") {
            document.getElementById("spnMail").style.display = "block";
            mensaje += "Mail vacio";
            mailErroneo = true;
        }
        if (clave == "") {
            document.getElementById("spnClave").style.display = "block";
            mensaje += "  -  Clave vacia";
            claveErroneo = true;
        }
        if ((clave.length > 8 || clave.length < 4)) {
            document.getElementById("spnClave").style.display = "block";
            mensaje += " - Error en la cantidad de caracteres";
            claveErroneo = true;
        }
        var emailRegex = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
        //Se muestra un texto a modo de ejemplo, luego va a ser un icono
        if (!mailErroneo) {
            if (emailRegex.test(mail)) {
            }
            else {
                document.getElementById("spnMail").style.display = "block";
                mailErroneo = true;
                mensaje += "  -Error en el formato del mail";
            }
        }
        if (claveErroneo != false || mailErroneo != false) {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>' + mensaje + '</strong></div>');
            return true;
        }
        else {
            return true;
        }
    };
    Manejador.VerificarUsuarioJson = function () {
        if (!Manejador.validador()) {
            return "";
        }
        var mail = $("#mail").val();
        var clave = $("#clave").val();
        var arrayJson = localStorage.getItem("arrayJson");
        var json = JSON.parse(arrayJson);
        var validador = false;
        for (var i = 0; i < json.length; i++) {
            if (mail == json[i].mail) {
                if (json[i].clave == clave) {
                    validador = true;
                    break;
                }
            }
        }
        if (validador) {
            $.ajax({
                type: 'GET',
                url: "../BACKEND/",
                dataType: "json",
                contentType: false,
                processData: false,
            })
                .done(function (objJson) {
                localStorage.setItem("mitoken", objJson);
                location.href = "principal.html";
            })
                .fail(function (aaa) {
                console.log(JSON.stringify(aaa));
            });
        }
        else {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error la contraceña no coincide con el mail</strong></div>');
        }
    };
    return Manejador;
}());
//# sourceMappingURL=Manejador.js.map