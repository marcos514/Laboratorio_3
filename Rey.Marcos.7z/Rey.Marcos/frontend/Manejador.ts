/// <reference path="node_modules/@types/jquery/index.d.ts" />
class Manejador 
{

    public static ArrayJson()
    {
        let strJson:string='[{"mail":"alberto@gmail.com","clave":"1234","nombre":"tomas","apellido":"martin","legajo":"5621","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"marcos@gmail.com","clave":"1234","nombre":"marcos","apellido":"rey","legajo":"789","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"tomas@gmail.com","clave":"1234","nombre":"tomas","apellido":"sanchez","legajo":"5648","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"juan@gmail.com","clave":"1234","nombre":"juan","apellido":"siñeris","legajo":"1264","perfil":"invitado","foto":"fotos/1234.jpg"},{"mail":"mica@gmail.com","clave":"1234","nombre":"micaela","apellido":"saez","legajo":"555","perfil":"invitado","foto":"fotos/1234.jpg"}]';
        if(localStorage.getItem("arrayJson"))
        {
            console.log("Usuarios cargados con antelacion");
            console.log(localStorage.getItem("arrayJson"));
        }
        else
        {
            localStorage.setItem("arrayJson",strJson);
            console.log(strJson);
        }
        
        
    }

    public static ValidarCamposUsuario()
    {
        $("#divAlert").html(""); 
        let nombre:any=$("#nombre").val();
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();
        let clave2:any=$("#claveComparar").val();
        let foto : any = (<HTMLInputElement>document.getElementById("foto"));
        let apellido:any=$("#apellido").val();
        let legajo:any=$("#legajo").val();

        let validadorNombre=false;
        let validadorClave=false;
        let validadorClave2=false;
        let validadorMail=false;
        let validadorApellido=false;
        let validadorLegajo=false;
        let validadorFoto=false;

        let mensaje="";
        if(nombre=="")
        {
            (<HTMLSpanElement>document.getElementById("spnNombre")).style.display="block";
            mensaje+="Ingresar nombre<br>";
            validadorNombre=true;
        }
        else if(nombre.length>10)
        {
            (<HTMLSpanElement>document.getElementById("spnNombre")).style.display="block";
            mensaje+="Nombre muy largo<br>";
            validadorNombre=true;
        }


        if(apellido=="")
        {
            (<HTMLSpanElement>document.getElementById("spnApellido")).style.display="block";
            mensaje+="Ingresar Apellido<br>";
            validadorApellido=true;
        }
        else if(apellido.length>15)
        {
            (<HTMLSpanElement>document.getElementById("spnApellido")).style.display="block";
            mensaje+="Apellido muy largo<br>";
            validadorApellido=true;
        }

        if(legajo=="")
        {
            (<HTMLSpanElement>document.getElementById("spnLegajo")).style.display="block";
            mensaje+="Ingresar Legajo<br>";
            validadorApellido=true;
        }
        else if(legajo.length>6||legajo.length<3 )
        {
            (<HTMLSpanElement>document.getElementById("spnLegajo")).style.display="block";
            mensaje+="Legajo formato erroneo<br>";
            validadorApellido=true;
        }
        else
        {
            let json:any =localStorage.getItem("arrayJson");
            json=JSON.parse(json);
            for(let i=0;i<json.length;i++)
            {
                if(legajo==json[i]["legajo"])
                {
                    validadorLegajo=true;
                    mensaje+="Legajo repetido<br>";
                    (<HTMLSpanElement>document.getElementById("spnLegajo")).style.display="block";
                }
            }

        }

        if(mail=="")
        {
            (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
            mensaje+="Ingresar Mail<br>";
            validadorMail=true;
        }
        else
        {
            let emailRegex:any = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            //Se muestra un texto a modo de ejemplo, luego va a ser un icono
        
            if (emailRegex.test(mail)) 
            {
                let arrayJson:any=localStorage.getItem("arrayJson");
                let json:any=JSON.parse(arrayJson);
                let validador:boolean=false;
                for(let i=0;i<json.length;i++)
                {
                    if(mail==json[i].mail)
                    {
                        
                        (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
                         validadorMail=true;
                        mensaje+= "Mail Repetido<br>"; 
                        break;              
                    }
                }
          
            } 
            else 
            {
                (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
                validadorMail=true;
                mensaje+= "Formato del mail erroneo<br>"; 
            }
        }


        if(clave=="")
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+="Ingresar Clave<br>";
            validadorNombre=true;
        }
        else if(clave.length>8||clave.length<4)
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+="Clave rango invalido<br>";
            validadorClave=true;
        }

        if(clave2=="")
        {
            (<HTMLSpanElement>document.getElementById("spnClaveRepetir")).style.display="block";
            mensaje+="Ingrese confirmacion de clave<br>";
            validadorNombre=true;
        }
        else if(clave2.length>8||clave2.length<4)
        {
            (<HTMLSpanElement>document.getElementById("spnClaveRepetir")).style.display="block";            
            mensaje+="Clave a confirmar formato erroneo<br>";
            validadorClave=true;
        }

        
        if(foto.files.length==0)
        {
            (<HTMLSpanElement>document.getElementById("spnFoto")).style.display="block";            
            mensaje+="Ingresar Foto <br>";
            validadorFoto=true;
        }
        else
        {
            let foto : any = (<HTMLInputElement>document.getElementById("foto"));
            let form:FormData=new FormData();


            if(foto.files.length==0)
            {
                alert("Error");
                return "";
            }
            form.append("foto",foto.files[0]);

            $.ajax({
                type: 'POST',
                url: "../BACKEND/",
                dataType:"json",
                data:form,
                contentType: false,
                processData: false,
            })
            .done(function (objJson) {

                if(objJson=="error")
                {
                    (<HTMLSpanElement>document.getElementById("spnFoto")).style.display="block";            
                    mensaje+="Extencion foto invalido <br>";
                    validadorFoto=true;
                }
            })
            .fail(function(aaa){
                console.log(JSON.stringify(aaa));
                
            });
        }

        if(mensaje!="")
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>'+mensaje+'</strong></div>');
            return true;
        }
        else
        {
            return false;
        }
        
    
    }
    public static AgregarUsuario() 
    {
        $("#divAlert").html("");
        
        if(Manejador.ValidarCamposUsuario())
        {
            return "";
        }
        
        let nombre:any=$("#nombre").val();
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();
        let clave2:any=$("#claveComparar").val();
        let foto : any = (<HTMLInputElement>document.getElementById("foto"));
        let apellido:any=$("#apellido").val();
        let perfil:any=$("#perfil").val();
        let legajo:any=$("#legajo").val();

        if(clave==clave2)
        {
            let arrayJson:any=localStorage.getItem("arrayJson");
            let json:any=JSON.parse(arrayJson);
            let validador:boolean=false;
            for(let i=0;i<json.length;i++)
            {
                if(legajo==json[i].legajo )
                {
                    validador=true;
                    break;              
                    
                }
            }
            for(let i=0;i<json.length;i++)
            {
                if(mail==json[i].mail )
                {
                    validador=true;
                    break;              
                }
            }
            if(validador)
            {
                $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error mail ya ingresado</strong></div>');     
            }
            else
            {
                let usuarioNuevo=JSON.parse('{"mail":"'+mail+'","clave":"'+clave+'","nombre":"'+nombre+'","apellido":"'+apellido+'","legajo":"'+legajo+'","perfil":"'+perfil+'","foto":"fotos/'+json.length+'.jpg"}')
                json.push(usuarioNuevo);
                localStorage.setItem("arrayJson",JSON.stringify(json));
                location.href ="principal.html";
            }
            
        }
        else
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error la contraceña no coincide con el mail</strong></div>');
            
        }
        

         
    }

    public static validador()
    {
        $("#divAlert").html("");                        
        
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();
        let mensaje="";
        let mailErroneo=false;
        let claveErroneo=false;
        if(mail=="")
        {
            (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
            mensaje+="Mail vacio";
            mailErroneo=true;
        }
        if(clave=="")
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+="  -  Clave vacia";
            
            claveErroneo=true;          
        }
        if((clave.length>8 || clave.length<4) )
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+=" - Error en la cantidad de caracteres";
            claveErroneo=true;
            
        }    
        let emailRegex:any = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            //Se muestra un texto a modo de ejemplo, luego va a ser un icono
        if(!mailErroneo)
        {
            if (emailRegex.test(mail)) 
            {
          
            } 
            else 
            {
                (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
                mailErroneo=true;
                mensaje+= "  -Error en el formato del mail";
                
            }
        }
        
        
        if(claveErroneo!=false || mailErroneo!=false)
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>'+mensaje+'</strong></div>');                        
            return true;
        }
        else
        {
            return true;
        }
    }

    public static Lista()
    {
        let arrayJson:any=localStorage.getItem("arrayJson");
        let usuario:any=localStorage.getItem("mitoken");

        let json:any=JSON.parse(arrayJson);
        $("#divLista").html("");
        let i:number=0;
    
        $.ajax({
            type: 'get',
            url: "../BACKEND/",
            dataType:"json",
            contentType: false,
            processData: false,
            headers:{"token":usuario}
        })
        .done(function (objJson) {

            if(objJson=="error")
            {
                location.href="login.html";
            }
            console.log(objJson);
            if(objJson=="host")
            {
                let lista:string='<table class="table"><thead><tr><th scope="col">Mail</th><th scope="col">Nombre</th><th scope="col">Apelido</th><th scope="col">Perfil</th><th colspan="" scope="col">Legajo</th><th  scope="col">Foto</th></tr> <th  scope="col">borrar</th></tr></thead><tbody>';
                for (let i = 0; i < json.length; i++) 
                {
                    lista+='<tr><td><input id="'+i+'"name="'+i+'titulo" type="text" class="form-control" value="'+json[i].mail+'" readonly></td><td><input id="'+i+'empresa" type="text" class="form-control" name="'+i+'empresa" value="'+json[i].nombre+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].apellido+'"></td><td><input type=""class="form-control" name="'+i+'precio"id="'+i+'precio" value="'+json[i].perfil+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].legajo+'"></td><td><img src="'+json[i].foto+'" width="50px" height="50px"></td><td><a class="btn btn-danger" onclick="Manejador.borrar('+i+')" role="button">Borrar</a></td></tr>';
                }
                $("#divLista").html(lista+'</tbody></table>');
            }
            else
            {
                let lista:string='<table class="table"><thead><tr><th scope="col">Mail</th><th scope="col">Nombre</th><th scope="col">Apelido</th><th scope="col">Perfil</th><th colspan="" scope="col">Legajo</th><th  scope="col">Foto</th></tr></thead><tbody>';
                for (let i = 0; i < json.length; i++) 
                {
                    lista+='<tr><td><input id="'+i+'"name="'+i+'titulo" type="text" class="form-control" value="'+json[i].mail+'" readonly></td><td><input id="'+i+'empresa" type="text" class="form-control" name="'+i+'empresa" value="'+json[i].nombre+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].apellido+'"></td><td><input type=""class="form-control" name="'+i+'precio"id="'+i+'precio" value="'+json[i].perfil+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].legajo+'"></td><td><img src="'+json[i].foto+'" width="50px" height="50px"></td></tr>';
                }

                $("#divLista").html(lista+'</tbody></table>');
            }
        })
        .fail(function(aaa){
            console.log(JSON.stringify(aaa));
            
        });

    }

    public static borrar(i:number)
    {
        let arrayJson:any=localStorage.getItem("arrayJson");
        let json:any=JSON.parse(arrayJson);
        json.splice(i, 1);
        location.href="principal.html";
    }
    public static VerificarUsuarioJson() 
    {
        if(!Manejador.validador())
        {
            return "";
        }
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();

        
        let arrayJson:any=localStorage.getItem("arrayJson");
        let json:any=JSON.parse(arrayJson);
        let validador:boolean=false;
        let nombre:any;
        let apellido:any;
        let perfil:any;
        for(let i=0;i<json.length;i++)
        {
            if(mail==json[i].mail )
            {
                if(json[i].clave==clave)
                {
                    nombre=json[i].nombre;
                    apellido=json[i].apellido;
                    perfil=json[i].perfil;
                    validador=true;
                    break;              
                }
            }
        }
        if(validador)
        {
            let form:FormData=new FormData();
            form.append("nombre",nombre);
            form.append("apellido",apellido);
            form.append("perfil",perfil);
            form.append("correo",mail);

            $.ajax({
                type: 'post',
                url: "../BACKEND/json",
                dataType:"json",
                data:form,
                contentType: false,
                processData: false,
            })
            .done(function (objJson) {
                localStorage.setItem("mitoken",objJson);
                location.href="principal.html";
            })
            .fail(function(aaa){
                console.log(JSON.stringify(aaa));
                
            });
                  
        }
        else
        {
            
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error la contraceña no coincide con el mail</strong></div>');
        }
        
        
    }


}