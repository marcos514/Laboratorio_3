<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";



use Firebase\JWT\JWT as JWT;


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);



$app->post('[/]', function ($request, $response) 
{
    if(isset($_FILES["foto"]))
    {
        $extencion=pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);

        if($extencion!="jpg"&&$extencion!="jpeg")
        {
            return $response->withJson("Error",200);
        }
        else
        {
            return $response->withJson("Ok",200);
        }
        
    }
    
    
});

$app->get('[/]', function ($request, $response) 
{
    $array=$array=array("exp"=>time()+30,"iat"=>time());
    $token=JWT::encode($array,"clave");
    return $response->withJson($token,200);
    
});




$app->run();

?>