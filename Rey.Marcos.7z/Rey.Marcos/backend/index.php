<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";



use Firebase\JWT\JWT as JWT;


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);



$app->post('[/]', function ($request, $response) 
{
    if(isset($_FILES["foto"]))
    {
        $extencion=pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);

        if($extencion!="jpg"&&$extencion!="jpeg")
        {
            return $response->withJson("Error",200);
        }
        else
        {
            $extencion=pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);
            $tmp_name=$_FILES["foto"]["tmp_name"];
            move_uploaded_file($tmp_name,"../fotos/".$_POST["legajo"].".jpg");   
            return $response->withJson("Ok",200);
        }
        
    }
    
    
});

$app->post('/json', function ($request, $response) 
{
    $array=array("correo"=>$_POST["correo"],"nombre"=>$_POST["nombre"], "apellido"=>$_POST["apellido"],  "perfil"=>$_POST["perfil"], "exp"=>time()+15,"iat"=>time());
    $token=JWT::encode($array,"clave");
    return $response->withJson($token,200);
    
});

$app->get('[/]', function ($request, $response) 
{
    $token=($request->getHeader("token")[0]);
    try
        {

            $todo= JWT::decode($token,"clave",["HS256"]);
            
            return $response->withJson($todo->perfil,200);
        }
        catch(Exception $e)
        {
            return $response->withJson("error",200);

        }
    return $response->withJson($token,200);
    
});




$app->run();

?>