namespace Entidades
{
    export class Ropa
    {   
        protected _codigo:number;
        protected _nombre:string;
        protected _precio:number;

        public constructor(codigo:number,nombre:string,precio:number) 
        {
            this._codigo=codigo;
            this._nombre=nombre;
            this._precio=precio;
        }

        public ToString():string
        {
            let strJson:string=`"codigo":"${this._codigo}","precio":${this._precio},"nombre":"${this._nombre}"`;
            //let objJason:JSON=JSON.parse(strJson);
            return strJson;
        }


    }

}