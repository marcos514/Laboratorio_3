/// <reference path="Persona.ts"/>

namespace Entidades
{
    export class Ciudadano extends Persona
    {
        protected _dni:number;
        protected _pais:string;

        public constructor(nombre:string,apellido:string,edad:number,dni:number,pais:string)
        {
            super(nombre,apellido,edad);
            this._dni= dni;
            this._pais=pais;
        }

        public ciudadanoToString():string
        {
            return "{"+this.personaToString()+",Dni:"+this._dni+",Pais: "+this._pais+"}";
        }
    }

}