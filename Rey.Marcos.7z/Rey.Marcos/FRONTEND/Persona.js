"use strict";
var Entidades;
(function (Entidades) {
    var Persona = /** @class */ (function () {
        function Persona(nombre, apellido, edad) {
            this._apellido = apellido;
            this._edad = edad;
            this._nombre = nombre;
        }
        Persona.prototype.personaToString = function () {
            return "Nombre:" + this._nombre + ",Apellido:" + this._apellido + ",Edad:" + this._edad;
        };
        return Persona;
    }());
    Entidades.Persona = Persona;
})(Entidades || (Entidades = {}));
//# sourceMappingURL=Persona.js.map