/// <reference path="ajax/Ajax.ts"/>
/// <reference path="Ciudadano.ts"/>

namespace Test
{
    export function AgregarCiudadano(valor:string)
    {

        let nombre=(<HTMLInputElement>document.getElementById("txtNombre")).value;
        let apellido=(<HTMLInputElement>document.getElementById("txtApellido")).value;
        let edad=(<HTMLInputElement>document.getElementById("txtEdad")).value;
        let dni=((<HTMLInputElement>document.getElementById("txtDni")).value);
        let pais=(<HTMLInputElement>document.getElementById("cboPais")).value;

        
        let ciudadano=new Entidades.Ciudadano(nombre,apellido, +edad,+dni,pais);
        let ajax:Ajax=new Ajax();
        if(valor=="agregar")
        {
           
            ajax.Post("../BACKEND/administrar.php",(mostrar:string)=>{},"cadenaJson"+ciudadano.ciudadanoToString()+"&caso:agregar");
        }
        else
        {
            (<HTMLInputElement>document.getElementById("btnModificar")).onclick.arguments="AgregarCiudadanos(agregar)";
            (<HTMLInputElement>document.getElementById("txtDni")).readOnly=false;
            ajax.Post("../BACKEND/administrar.php",(mostrar:string)=>{},"cadenaJson"+ciudadano.ciudadanoToString()+"&caso:modificar");

        }
    }

    export function MostarCiudadanos()
    {
        let ajax:Ajax=new Ajax();
        ajax.Post("../BACKEND/administrar.php",(mostrar:string)=>{
            let strJson:string=mostrar;
            let objJson:JSON[]=JSON.parse(strJson);
            let CiudadanosStr="";


            for(let i=0;i<objJson.length;i++)
            {
                //let ciudadano:Entidades.Ciudadano=new Entidades.Ciudadano((objJson[i])["Nombre"],objJson[i]["Apellido"],+objJson[i]["Edad"],+objJson[i]["Dni"],objJson[i]["Pais"]);
                
                
                
                
                //CiudadanosStr+="<h5>"+ciudadano.ciudadanoToString()+"<input type='button' value='Eliminar'onclick='EliminarCiudadano("+objJson[i]+")'/> </h5>";
            }

        },"caso:mostrar");
    }

    export function EliminarCiudadano(ciudadanoAjax:string)
    {
        let ajax:Ajax=new Ajax();
        let aa:JSON=JSON.parse(ciudadanoAjax);
        alert("El ciudadano a ser eliminado va a ser: "+ aa.Apellido+" - "+aa.Nombre);
        ajax.Post("../BACKEND/administrar.php",(mostrar:string)=>{
            MostarCiudadanos();
        },"cadenaJson"+ciudadanoAjax+"caso:eliminar");
    }

    export function ModificarCiudadano(ciudadanoAjax:string)
    {
        /*let ajax:Ajax=new Ajax();
        let json:JSON=JSON.parse(ciudadanoAjax);
        (<HTMLInputElement>document.getElementById("txtNombre")).value=json[0];
        (<HTMLInputElement>document.getElementById("txtApellido")).value=json[1];
        (<HTMLInputElement>document.getElementById("txtEdad")).value=json[2];
        (<HTMLInputElement>document.getElementById("txtDni")).value=json[3];
        (<HTMLInputElement>document.getElementById("txtDni")).readOnly=true;
        (<HTMLInputElement>document.getElementById("cboPais")).value=json[4];
        (<HTMLInputElement>document.getElementById("btnModificar")).onclick.arguments="AgregarCiudadano('modificar')";
    */
    }


}