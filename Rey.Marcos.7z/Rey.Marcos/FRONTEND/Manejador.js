"use strict";
/// <reference path="ajax/Ajax.ts"/>
/// <reference path="Ciudadano.ts"/>
var Test;
(function (Test) {
    function AgregarCiudadano(valor) {
        var nombre = document.getElementById("txtNombre").value;
        var apellido = document.getElementById("txtApellido").value;
        var edad = document.getElementById("txtEdad").value;
        var dni = (document.getElementById("txtDni").value);
        var pais = document.getElementById("cboPais").value;
        var ciudadano = new Entidades.Ciudadano(nombre, apellido, +edad, +dni, pais);
        var ajax = new Ajax();
        if (valor == "agregar") {
            ajax.Post("../BACKEND/administrar.php", function (mostrar) { }, "cadenaJson" + ciudadano.ciudadanoToString() + "&caso:agregar");
        }
        else {
            document.getElementById("btnModificar").onclick.arguments = "AgregarCiudadanos(agregar)";
            document.getElementById("txtDni").readOnly = false;
            ajax.Post("../BACKEND/administrar.php", function (mostrar) { }, "cadenaJson" + ciudadano.ciudadanoToString() + "&caso:modificar");
        }
    }
    Test.AgregarCiudadano = AgregarCiudadano;
    function MostarCiudadanos() {
        var ajax = new Ajax();
        ajax.Post("../BACKEND/administrar.php", function (mostrar) {
            var strJson = mostrar;
            var objJson = JSON.parse(strJson);
            var CiudadanosStr = "";
            for (var i = 0; i < objJson.length; i++) {
                //let ciudadano:Entidades.Ciudadano=new Entidades.Ciudadano((objJson[i])["Nombre"],objJson[i]["Apellido"],+objJson[i]["Edad"],+objJson[i]["Dni"],objJson[i]["Pais"]);
                //CiudadanosStr+="<h5>"+ciudadano.ciudadanoToString()+"<input type='button' value='Eliminar'onclick='EliminarCiudadano("+objJson[i]+")'/> </h5>";
            }
        }, "caso:mostrar");
    }
    Test.MostarCiudadanos = MostarCiudadanos;
    function EliminarCiudadano(ciudadanoAjax) {
        var ajax = new Ajax();
        var aa = JSON.parse(ciudadanoAjax);
        alert("El ciudadano a ser eliminado va a ser: " + aa.Apellido + " - " + aa.Nombre);
        ajax.Post("../BACKEND/administrar.php", function (mostrar) {
            MostarCiudadanos();
        }, "cadenaJson" + ciudadanoAjax + "caso:eliminar");
    }
    Test.EliminarCiudadano = EliminarCiudadano;
    function ModificarCiudadano(ciudadanoAjax) {
        /*let ajax:Ajax=new Ajax();
        let json:JSON=JSON.parse(ciudadanoAjax);
        (<HTMLInputElement>document.getElementById("txtNombre")).value=json[0];
        (<HTMLInputElement>document.getElementById("txtApellido")).value=json[1];
        (<HTMLInputElement>document.getElementById("txtEdad")).value=json[2];
        (<HTMLInputElement>document.getElementById("txtDni")).value=json[3];
        (<HTMLInputElement>document.getElementById("txtDni")).readOnly=true;
        (<HTMLInputElement>document.getElementById("cboPais")).value=json[4];
        (<HTMLInputElement>document.getElementById("btnModificar")).onclick.arguments="AgregarCiudadano('modificar')";
    */
    }
    Test.ModificarCiudadano = ModificarCiudadano;
})(Test || (Test = {}));
//# sourceMappingURL=Manejador.js.map