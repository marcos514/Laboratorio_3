<?php
$caso = isset($_POST["caso"]) ? $_POST["caso"] : null;
sleep(1);


switch ($caso) 
{

    case 'agregar':
        $cadenaJSON = isset($_POST['cadenaJson']) ? trim($_POST['cadenaJson']) : null;
        $cadenaJSON=str_replace("\\","",$cadenaJSON);
        $cadenaJSON=str_replace('"{',"{",$cadenaJSON);
        $cadenaJSON=str_replace('}"',"}",$cadenaJSON);
        $json=json_decode($cadenaJSON);

        

        // lo agrego si no esta 
        if(file_exists(trim("fotos/".$json->nombre.$json->codigo.".jpg")))
        {
            $resultado["TodoOK"] = false;
        }
        else
        {
            
            if(move_uploaded_file($_FILES["foto"]["tmp_name"],trim("fotos/".$json->nombre.$json->codigo.".jpg")))
            {
                $ar = fopen("./camperas.json", "a");
            
                $cant = fwrite($ar, "\r\n".$cadenaJSON);

                fclose($ar);

                $resultado["TodoOK"] = $cant > 0 ? true : false;
            }
            else
            {
            $resultado["TodoOK"] = false;                
            }

        }



    
        echo json_encode($resultado);
        break;

    case 'mostrar':
    
        $a = fopen("./camperas.json", "r");

        $string = "";

        while(!feof($a)){
        
            $linea = trim(fgets($a));
        
            if(strlen($linea) > 0)
                $string .=  $linea . ',';        
        }
        
        fclose($a);

        $string = substr($string, 0, strlen($string)-1);        
        
        echo ('['.$string.']');
        
        break;

    case 'eliminar':

        $cadenaJSON = isset($_POST['cadenaJson']) ? $_POST['cadenaJson'] : null;
        $cadenaJSON=str_replace("\\","",$cadenaJSON);
        $cadenaJSON=str_replace('"{',"{",$cadenaJSON);
        $cadenaJSON=str_replace('}"',"}",$cadenaJSON);
        $obj = json_decode($cadenaJSON);
        

        $a = fopen("./camperas.json","r");
        

        $string = '';

        while(!feof($a)){

            $linea = trim(fgets($a));

            if(strlen($linea) > 0){

                $objLinea = json_decode($linea);

                if($objLinea->codigo == $obj->codigo)
                {

                    move_uploaded_file(trim("./fotos/".$objLinea->nombre.$objLinea->codigo.".jpg"),trim("./fotosEliminadas/".$objLinea->nombre.$objLinea->codigo.".jpg")); 
                    continue;
                }

                $string .= $linea . "\r\n";
            }         
        }

        fclose($a);

        $objRetorno = new stdClass();
        $objRetorno->TodoOK = TRUE;

        $a = fopen("./camperas.json","w");
        
        $cant = fwrite($a, $string);

        fclose($a);

        echo json_encode($objRetorno);        
        
        break;

    case 'modificar':

        $cadenaJSON = isset($_POST['cadenaJson']) ? $_POST['cadenaJson'] : null;
        $cadenaJSON=str_replace("\\","",$cadenaJSON);
        $cadenaJSON=str_replace('"{',"{",$cadenaJSON);
        $cadenaJSON=str_replace('}"',"}",$cadenaJSON);
        $obj = json_decode($cadenaJSON);
        

        $a = fopen("./camperas.json","r");

        $string = '';

        while(!feof($a)){

            $linea = trim(fgets($a));
            
            if(strlen($linea) > 0){
                
                $objLinea = json_decode($linea);

                if($objLinea->codigo == $obj->codigo){  
                    move_uploaded_file(trim("fotos/".$objLinea->nombre.$objLinea->codigo.".jpg"),trim("fotosModificar/".$objLinea->nombre.$objLinea->codigo.".jpg"));                     
                    continue;
                }
                
                $string .= $linea . "\r\n";
            }         
        }

        $string .=  $cadenaJSON . "\r\n";
        move_uploaded_file($_FILES["foto"]["tmp_name"],$obj->path);
        
        

        fclose($a);

        $objRetorno = new stdClass();
        $objRetorno->TodoOK = TRUE;

        $a = fopen("./camperas.json","w");
        
        $cant = fwrite($a, $string);

        fclose($a);

        if($cant < 1){
            $objRetorno->TodoOK = FALSE;
        }

        echo json_encode($objRetorno);        

        break;

    case "marcas":
    
        $a = fopen("./colores.json","r");
        $paises = fread($a, filesize("./colores.json"));
        fclose($a);

        echo ($paises);

        break;
    default:
        echo ":(";
        break;
}