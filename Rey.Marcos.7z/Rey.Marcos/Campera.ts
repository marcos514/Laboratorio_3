/// <reference path="Ropa.ts"/>


namespace Entidades
{
    export class Campera extends Ropa
    {   
        protected _talle:string;
        protected _color:string;
        protected _path:string;

        public constructor(codigo:number,nombre:string,precio:number,talle:string,color:string,path:string) 
        {
            super(codigo,nombre,precio);
            this._talle=talle;
            this._color=color;
            this._path=path;
        }

        public ToJason():string
        {
            let strJson:string=`{${this.ToString()},"talle":${this._talle},"color":"${this._color}","path":"${this._path}"}`;
            let objJason:JSON=JSON.parse(strJson);
            return strJson;
        }


    }

}