var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Entidades;
(function (Entidades) {
    var Ropa = /** @class */ (function () {
        function Ropa(codigo, nombre, precio) {
            this._codigo = codigo;
            this._nombre = nombre;
            this._precio = precio;
        }
        Ropa.prototype.ToString = function () {
            var strJson = "\"codigo\":\"" + this._codigo + "\",\"precio\":" + this._precio + ",\"nombre\":\"" + this._nombre + "\"";
            //let objJason:JSON=JSON.parse(strJson);
            return strJson;
        };
        return Ropa;
    }());
    Entidades.Ropa = Ropa;
})(Entidades || (Entidades = {}));
/// <reference path="node_modules/@types/jquery/index.d.ts" />
/// <reference path="Ropa.ts"/>
var Test;
(function (Test) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.Agregar = function () {
            var pagina = "./BACKEND/administrar.php";
            //let archivo : any = (<HTMLInputElement>document.getElementById("foto"));
            var nombre = document.getElementById("txtNombre").value;
            var strprecio = document.getElementById("txtPrecio").value;
            var codigo = document.getElementById("txtCodigo").value;
            var talle = document.getElementById("txtTalle").value;
            var color = document.getElementById("txtColor").value;
            //codigo:number,nombre:string,precio:number,talle:string,color:string
            //let path:string="fotos/"+patente+".jpg";
            var precio = Number(strprecio);
            var campera = new Entidades.Campera(Number(codigo), nombre, Number(strprecio), talle, color);
            var formData = new FormData();
            formData.append("cadenaJson", JSON.stringify(campera.ToJason()));
            if ($("#hdnIdModificacion").val() == "modificar") {
                formData.append("caso", "modificar");
            }
            else {
                formData.append("caso", "agregar");
            }
            //formData.append("foto", archivo.files[0]);
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                if (params.TodoOK) {
                    if ($("#hdnIdModificacion").val() == "modificar") {
                        Manejadora.MostrarCamperas();
                    }
                    console.log("Todo ok");
                    $("#txtNombre").val("");
                    $("#txtPrecio").val("");
                    $("#txtCodigo").val("");
                    $("#txtTalle").val("");
                    $("#txtCodigo").prop('readOnly', false);
                    $("#hdnIdModificacion").val("");
                    $("#btnAgregar").val("Agregar");
                }
                else {
                    console.log("Error al subir el archivo");
                }
            })
                .fail(function (params) {
                console.log(params);
            });
        };
        Manejadora.MostrarCamperas = function () {
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("caso", "mostrar");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                $("#divTabla").html("");
                $("#divTabla").append("<tr><td colspan='2'>Nombre</td><td colspan='2'>Precio</td><td colspan='2'>Codigo</td><td colspan='2'>Talle</td><td colspan='2'>Color</td><td></td></tr>");
                for (var i = 0; i < params.length; i++) {
                    var json = JSON.stringify(params[i]);
                    $("#divTabla").append("<tr><td colspan='2'>" + params[i].nombre + "</td><td colspan='2'>" + params[i].precio + "</td><td colspan='2'>" + params[i].codigo + "</td><td colspan='2'>" + params[i].talle + "</td><td colspan='2'>" + params[i].color + "</td><td><input type='button' onclick='Test.Manejadora.EliminarCampera(" + json + ")' value='Eliminar'/><input type='button' onclick='Test.Manejadora.ModificarCampera(" + json + ")' value='Modificar'/> </td></tr>");
                }
            })
                .fail(function (params) {
                console.log(params);
            });
        };
        Manejadora.FiltrarCamperasPorColor = function () {
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("caso", "mostrar");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                $("#divTabla").html("");
                $("#divTabla").append("<tr><td colspan='2'>Nombre</td><td colspan='2'>Precio</td><td colspan='2'>Codigo</td><td colspan='2'>Talle</td><td colspan='2'>Color</td><td></td></tr>");
                for (var i = 0; i < params.length; i++) {
                    if (params[i].color == $("#txtColor").val()) {
                        var json = JSON.stringify(params[i]);
                        $("#divTabla").append("<tr><td colspan='2'>" + params[i].nombre + "</td><td colspan='2'>" + params[i].precio + "</td><td colspan='2'>" + params[i].codigo + "</td><td colspan='2'>" + params[i].talle + "</td><td colspan='2'>" + params[i].color + "</td><td><input type='button' onclick='Test.Manejadora.EliminarCampera(" + json + ")' value='Eliminar'/><input type='button' onclick='Test.Manejadora.ModificarCampera(" + json + ")' value='Modificar'/> </td></tr>");
                    }
                }
            })
                .fail(function (params) {
                console.log(params);
            });
        };
        Manejadora.EliminarCampera = function (jsonstr) {
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("cadenaJson", JSON.stringify(jsonstr));
            formData.append("caso", "eliminar");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                if (params.TodoOK) {
                    console.log("Todo ok");
                    Manejadora.MostrarCamperas();
                }
                else {
                    console.log("Error eliminar el archivo");
                }
            })
                .fail(function (params) {
                console.log(params);
            });
        };
        Manejadora.ModificarCampera = function (jsonstr) {
            $("#txtNombre").val(jsonstr.nombre);
            $("#txtPrecio").val(jsonstr.precio);
            $("#txtCodigo").val(jsonstr.codigo);
            $("#txtTalle").val(jsonstr.talle);
            $("#txtColor").val(jsonstr.color);
            $("#txtCodigo").prop('readOnly', true);
            $("#hdnIdModificacion").val("modificar");
            $("#btnAgregar").val("Modificar");
        };
        Manejadora.CargarColoresJSON = function () {
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("caso", "marcas");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                $("#txtColor").val("");
                for (var i = 0; i < params.length; i++) {
                    $("#txtColor").append("<option>" + params[i].descripcion + "</option>");
                }
            })
                .fail(function (params) {
                console.log(params);
            });
        };
        return Manejadora;
    }());
    Test.Manejadora = Manejadora;
})(Test || (Test = {}));
/// <reference path="Ropa.ts"/>
var Entidades;
(function (Entidades) {
    var Campera = /** @class */ (function (_super) {
        __extends(Campera, _super);
        function Campera(codigo, nombre, precio, talle, color) {
            var _this = _super.call(this, codigo, nombre, precio) || this;
            _this._talle = talle;
            _this._color = color;
            return _this;
        }
        Campera.prototype.ToJason = function () {
            var strJson = "{" + this.ToString() + ",\"talle\":" + this._talle + ",\"color\":\"" + this._color + "\"}";
            var objJason = JSON.parse(strJson);
            return strJson;
        };
        return Campera;
    }(Entidades.Ropa));
    Entidades.Campera = Campera;
})(Entidades || (Entidades = {}));
