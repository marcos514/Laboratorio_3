var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Entidades;
(function (Entidades) {
    var Ropa = /** @class */ (function () {
        function Ropa(codigo, nombre, precio) {
            this._codigo = codigo;
            this._nombre = nombre;
            this._precio = precio;
        }
        Ropa.prototype.ToString = function () {
            var strJson = "\"codigo\":\"" + this._codigo + "\",\"precio\":" + this._precio + ",\"nombre\":\"" + this._nombre + "\"";
            //let objJason:JSON=JSON.parse(strJson);
            return strJson;
        };
        return Ropa;
    }());
    Entidades.Ropa = Ropa;
})(Entidades || (Entidades = {}));
/// <reference path="node_modules/@types/jquery/index.d.ts" />
/// <reference path="Ropa.ts"/>
var Test;
(function (Test) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.Agregar = function () {
            Manejadora.AdministrarSpinner(true);
            var pagina = "./BACKEND/administrar.php";
            var archivo = document.getElementById("foto");
            var nombre = document.getElementById("txtNombre").value;
            var strprecio = document.getElementById("txtPrecio").value;
            var codigo = document.getElementById("txtCodigo").value;
            var talle = document.getElementById("txtTalle").value;
            var color = document.getElementById("txtColor").value;
            //codigo:number,nombre:string,precio:number,talle:string,color:string
            var path = "fotos/" + nombre + codigo + ".jpg";
            var precio = Number(strprecio);
            var campera = new Entidades.Campera(Number(codigo), nombre, Number(strprecio), talle, color, path);
            var formData = new FormData();
            formData.append("cadenaJson", JSON.stringify(campera.ToJason()));
            if ($("#hdnIdModificacion").val() == "modificar") {
                formData.append("caso", "modificar");
            }
            else {
                formData.append("caso", "agregar");
            }
            formData.append("foto", archivo.files[0]);
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                Manejadora.AdministrarSpinner(false);
                if (params.TodoOK) {
                    if ($("#hdnIdModificacion").val() == "modificar") {
                        Manejadora.MostrarCamperas();
                    }
                    console.log("Todo ok");
                    Manejadora.LimpiarForm();
                }
                else {
                    console.log("Error al subir el archivo");
                }
            })
                .fail(function (params) {
                Manejadora.AdministrarSpinner(false);
                console.log(params);
            });
        };
        Manejadora.MostrarCamperas = function () {
            var pagina = "./BACKEND/administrar.php";
            Manejadora.AdministrarSpinner(true);
            var formData = new FormData();
            formData.append("caso", "mostrar");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                Manejadora.AdministrarSpinner(false);
                $("#divTabla").html("");
                $("#divTabla").append("<tr><td colspan='2'>Nombre</td><td colspan='2'>Precio</td><td colspan='2'>Codigo</td><td colspan='2'>Talle</td><td colspan='2'>Color</td><td>Foto</td><td></td></tr>");
                for (var i = 0; i < params.length; i++) {
                    var json = JSON.stringify(params[i]);
                    $("#divTabla").append("<tr><td colspan='2'>" + params[i].nombre + "</td><td colspan='2'>" + params[i].precio + "</td><td colspan='2'>" + params[i].codigo + "</td><td colspan='2'>" + params[i].talle + "</td><td colspan='2'>" + params[i].color + "</td><td><img id=\"imgFoto\" src='BACKEND/fotos/" + params[i].nombre + params[i].codigo + ".jpg' width=\"50px\" height=\"50px\" /></td><td><input type='button' onclick='Test.Manejadora.EliminarCampera(" + json + ")' value='Eliminar'/><input type='button' onclick='Test.Manejadora.ModificarCampera(" + json + ")' value='Modificar'/> </td></tr>");
                }
            })
                .fail(function (params) {
                Manejadora.AdministrarSpinner(false);
                console.log(params);
            });
        };
        Manejadora.FiltrarCamperasPorColor = function () {
            Manejadora.AdministrarSpinner(true);
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("caso", "mostrar");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                Manejadora.AdministrarSpinner(false);
                $("#divTabla").html("");
                $("#divTabla").append("<tr><td colspan='2'>Nombre</td><td colspan='2'>Precio</td><td colspan='2'>Codigo</td><td colspan='2'>Talle</td><td colspan='2'>Color</td><td>Foto</td><td></td></tr>");
                for (var i = 0; i < params.length; i++) {
                    if (params[i].color == $("#txtColor").val()) {
                        var json = JSON.stringify(params[i]);
                        $("#divTabla").append("<tr><td colspan='2'>" + params[i].nombre + "</td><td colspan='2'>" + params[i].precio + "</td><td colspan='2'>" + params[i].codigo + "</td><td colspan='2'>" + params[i].talle + "</td><td colspan='2'>" + params[i].color + "</td><td><img id=\"imgFoto\" src='BACKEND/fotos/" + params[i].nombre + params[i].codigo + ".jpg' width=\"50px\" height=\"50px\" /></td><td><input type='button' onclick='Test.Manejadora.EliminarCampera(" + json + ")' value='Eliminar'/><input type='button' onclick='Test.Manejadora.ModificarCampera(" + json + ")' value='Modificar'/> </td></tr>");
                    }
                }
            })
                .fail(function (params) {
                Manejadora.AdministrarSpinner(false);
                console.log(params);
            });
        };
        Manejadora.EliminarCampera = function (jsonstr) {
            Manejadora.AdministrarSpinner(true);
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("cadenaJson", JSON.stringify(jsonstr));
            if (confirm("Quiere Eliminar a la campera: " + jsonstr.nombre + " - " + jsonstr.talle)) {
                formData.append("caso", "eliminar");
            }
            else {
                formData.append("caso", "...");
            }
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                Manejadora.AdministrarSpinner(false);
                if (params.TodoOK) {
                    console.log("Todo ok");
                    Manejadora.MostrarCamperas();
                }
                else {
                    console.log("Error eliminar el archivo");
                }
            })
                .fail(function (params) {
                Manejadora.AdministrarSpinner(false);
                console.log(params);
            });
        };
        Manejadora.ModificarCampera = function (jsonstr) {
            $("#txtNombre").val(jsonstr.nombre);
            $("#txtPrecio").val(jsonstr.precio);
            $("#txtCodigo").val(jsonstr.codigo);
            $("#txtTalle").val(jsonstr.talle);
            $("#txtColor").val(jsonstr.color);
            $("#txtCodigo").prop('readOnly', true);
            $("#hdnIdModificacion").val("modificar");
            $("#btnAgregar").val("Modificar");
            $("#foto").val("");
        };
        Manejadora.CargarColoresJSON = function () {
            Manejadora.AdministrarSpinner(true);
            var pagina = "./BACKEND/administrar.php";
            var formData = new FormData();
            formData.append("caso", "marcas");
            $.ajax({
                type: 'POST',
                url: pagina,
                dataType: "json",
                data: formData,
                contentType: false,
                processData: false
            })
                .done(function (params) {
                Manejadora.AdministrarSpinner(false);
                $("#txtColor").empty();
                for (var i = 0; i < params.length; i++) {
                    $("#txtColor").append("<option>" + params[i].descripcion + "</option>");
                }
            })
                .fail(function (params) {
                Manejadora.AdministrarSpinner(false);
                console.log(params);
            });
        };
        Manejadora.LimpiarForm = function () {
            $("#txtNombre").val("");
            $("#txtColor").val("Azul");
            $("#txtPrecio").val("");
            $("#txtCodigo").val("");
            $("#txtTalle").val("");
            $("#txtCodigo").prop('readOnly', false);
            $("#hdnIdModificacion").val("");
            $("#btnAgregar").val("Agregar");
        };
        Manejadora.AdministrarSpinner = function (mostrar) {
            if (mostrar) {
                document.getElementById("divSpinner").style.display = "block";
                document.getElementById("imgSpinner").src = "BACKEND/gif-load.gif";
            }
            else {
                document.getElementById("divSpinner").style.display = "none";
                document.getElementById("imgSpinner").src = "";
            }
        };
        return Manejadora;
    }());
    Test.Manejadora = Manejadora;
})(Test || (Test = {}));
/// <reference path="Ropa.ts"/>
var Entidades;
(function (Entidades) {
    var Campera = /** @class */ (function (_super) {
        __extends(Campera, _super);
        function Campera(codigo, nombre, precio, talle, color, path) {
            var _this = _super.call(this, codigo, nombre, precio) || this;
            _this._talle = talle;
            _this._color = color;
            _this._path = path;
            return _this;
        }
        Campera.prototype.ToJason = function () {
            var strJson = "{" + this.ToString() + ",\"talle\":" + this._talle + ",\"color\":\"" + this._color + "\",\"path\":\"" + this._path + "\"}";
            var objJason = JSON.parse(strJson);
            return strJson;
        };
        return Campera;
    }(Entidades.Ropa));
    Entidades.Campera = Campera;
})(Entidades || (Entidades = {}));
